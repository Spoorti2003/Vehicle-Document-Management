 <center>
  
   <h1><font size="7"> <font color="gray">Vehicle Document Management</font> </h1>
	<h2><marquee><font size="6"><font color=" 3041B"><i>One Life One World Explore It Unleashing My New World</i></font></marquee></h2>
	 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <html>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body  background="s.jpg">

<div class="topnav">
  <a class="active" href="#home">Home</a>
   
   <a href="dl_user.php">Driving Licence</a>
  <a href=" i_user.php">Insurance</a>
  <a href="vd_user.php">Vehicle Document</a>
  <a href="about_us.php">About</a>
   <a href="user_logout.php">logout</a>
</div>
<br>
<div style="padding-left:16px">
  
</div>

  <html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<br>
<style>
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  m  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
</head>


















<html>
<head>
 <style>
   body{
	   
   background-image:url('blue.jfif');
 background-repeat:no-repeat;
 background-attachment:fixed;
 
 background-size:100% 100%
   }
   </style> 
  
  </head>
<body>

<center>
</font>
<h1>  <p style="color:#AC3E31;">   <u><i>   ABOUT US  </i></u> </p>     </h1>  
<h2><p style="color:#303655;"> PROJECT ON VEHICLE MANAGEMENT SYSTEM  </p><h2>

 
 

 

<h1>  <p style="color:#AC3E31;"><u> <i>ACKNOWLEDGEMENT</i></u></p><h1>
<h3>Our journey towards achieving the destination for the design and development of this project has finally come to a fruitful culmination.<br> Our efforts and whole hearted cooperation of our lecturer has ended on a successful note. <br><br>During this journey we faced numerous unforeseen problems and unknown challenges. <br>Many people met us during this endeavour and enriched uswith their support and knowledge both personally and professionally that resulted in the project being for better than it could possibly have been without them.<br></h3>

 


<h1><p style="color:#AC3E31;">  <i><u>PROJECT SELECTION</u></i></p></h1>
<h3>Today the world is considered as a competitive world where everybody seeks for accuracy in least time.<br>Earlier paper work was the means to keep various records. It was very time consuming and not even that accurate. So, we decided to design and develop the Project called<i> VEHICLE MANAGEMENT SYSTEM </i>which eliminates the paper work and provides better option to the people for their Vehicle records.<br> It dealswith the maintenance of the records of the different categories of vehicles and their owners.<br> The user of this program can add records of the vehicles and their owners, view these records and can also edit them.
</h3>

<h2><p style="color:#00203fff;"> Email Address : spoortipatil2003@gmail.com</p></h2>





</center>
</body>
</html>















 
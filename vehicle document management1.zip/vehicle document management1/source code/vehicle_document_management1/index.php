<html>
<head>
<title>form</title>
     
	 <style>
.button {
  background-color: #4CAF50; /* user */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

 
 
</style>
</head>
<body bgcolor="khaki">
<center>
<title> project</title>
	 </head>
	 <body>
	 <br>
	 <h1><font size="55"><font color=" #CC313D"><i> Vehicle Document Management</i></font></h1>
	 <h3> <marquee>
	 <font color="00203FFF">Developed by:Spoorti.M.Patil <br>
	                                                    Spoorti.B.Pasannavar</marquee></font></h3>
					  
		<img src="pro1.JPG"> </img> <br></br>
		<p><h2>choose your model</h2></p>
		
		 <a href="user/login.php"><button class="button button1">user </button></a>
		 
        <a href="admin/admin.php"> <button class="button button2">admin</button></a>
	 
		 
		 
	 </center>
		</body>
		</html>